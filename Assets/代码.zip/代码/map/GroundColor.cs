// GroundColor.cs
using UnityEngine;
using UnityEngine.Tilemaps;

[RequireComponent(typeof(Tilemap))]
public class GroundColor : MonoBehaviour
{
    [Tooltip("�õ������ɫ���ԣ�ʮ�������� #85FF85��")]
    public Color groundColor = Color.white; // Ĭ�ϰ�ɫ
    public string ys; 
    void Reset()
    {
        groundColor = HexToColor(ys);
    }

    /// <summary>
    /// ��ʮ��������ɫ�ַ���תΪ Unity Color
    /// ֧�� "#RRGGBB" �� "RRGGBB"
    /// </summary>
    public static Color HexToColor(string hex)
    {

        if (string.IsNullOrEmpty(hex))
        {
            return Color.white;
        }

        if (hex.StartsWith("#"))
            hex = hex.Substring(1);

        if (hex.Length != 6)
        {
            Debug.LogError("��Ч��ʮ��������ɫ: " + hex);
            return Color.white;
        }

        byte r = byte.Parse(hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
        byte g = byte.Parse(hex.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
        byte b = byte.Parse(hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);

        return new Color32(r, g, b, 255);
    }
}