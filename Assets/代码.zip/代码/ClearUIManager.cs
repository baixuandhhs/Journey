using UnityEngine;
using UnityEngine.SceneManagement;

public class ClearUIManager : MonoBehaviour
{
    public void RestartGame()
    {
        Time.timeScale = 1f; // �ָ�ʱ��
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); // ���ص�ǰ����
    }

    public void BackToMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(0); 
    }
}