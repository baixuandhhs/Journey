using UnityEngine;

public class PotionItem : MonoBehaviour
{
    public bool isRed = true; // ��ѡΪ��ҩ������ѡΪ��ҩ

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerStats stats = other.GetComponent<PlayerStats>();
            if (stats != null)
            {
                stats.PickUpPotion(isRed);
                Destroy(gameObject); // ���������
            }
        }
    }
}