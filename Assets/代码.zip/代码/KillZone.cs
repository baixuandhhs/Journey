using UnityEngine;

public class KillZone : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerStats stats = other.GetComponent<PlayerStats>();
            if (stats != null)
            {
                // ǿ�ƽ�Ѫ����Ϊ 0
                stats.TakeDamage(stats.currentHealth);
            }
        }
    }
}