﻿using UnityEngine;
using System.Collections.Generic;

public class MagicBall : MonoBehaviour
{
    [Header("=== 基础设置 ===")]
    public bool isBigBall = false;
    public float speed = 12f;
    public float lifeTime = 3f;
    public float explosionRadius = 2.5f;

    [Header("=== 视觉组件 ===")]
    public SpriteRenderer spriteRenderer;

    private PlayerStats playerStats;
    private AttributeType ballAttribute;
    private float baseDamage;
    private List<EnemyStats> hitList = new List<EnemyStats>();

    void Awake()
    {
        // 确保不受重力影响，实现直线飞行
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        if (rb) rb.gravityScale = 0;
        Destroy(gameObject, lifeTime);
    }

   
    public void Init(AttributeType attr, float damage, Color themeColor, PlayerStats stats, float moveDir)
    {
        ballAttribute = attr;
        baseDamage = damage;
        playerStats = stats;

        if (spriteRenderer) spriteRenderer.color = themeColor;

        // 让法球的视觉朝向也根据移动方向镜像
        transform.localScale = new Vector3(moveDir * Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);

        // 染色拖尾
        TrailRenderer tr = GetComponent<TrailRenderer>();
        if (tr)
        {
            tr.startColor = themeColor;
            tr.endColor = new Color(themeColor.r, themeColor.g, themeColor.b, 0);

            // 确保拖尾能立即显示在正确位置
            tr.Clear();
        }

      
        GetComponent<Rigidbody2D>().velocity = new Vector2(moveDir * speed, 0);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // 过滤玩家、其它法球及 Trigger 区域
        if (collision.CompareTag("Player") || collision.CompareTag("Projectile") || collision.isTrigger) return;

        if (collision.CompareTag("Enemy"))
        {
            EnemyStats enemy = collision.GetComponent<EnemyStats>();
            if (enemy != null && !hitList.Contains(enemy))
            {
                hitList.Add(enemy);
                HandleImpact(enemy);
                // 普通小球撞击后消失，大法球穿透
                if (!isBigBall) Destroy(gameObject);
            }
        }

        // 撞墙逻辑
        if (collision.gameObject.layer == LayerMask.NameToLayer("Ground"))
        {
            // 如果是大球可以加个爆炸粒子 Instantiate...
            Destroy(gameObject);
        }
    }

    void HandleImpact(EnemyStats enemy)
    {
        if (enemy == null || playerStats == null) return;

        // 🔴 红色：伤害翻倍
        float damageMult = (ballAttribute == AttributeType.Red) ? 2.0f : 1.0f;
        enemy.TakeDamage(baseDamage * damageMult, ballAttribute);

        // 🔵 蓝色：法师远程普攻命中回 10 蓝
        if (ballAttribute == AttributeType.Blue && !isBigBall)
        {
            playerStats.RestoreMana(10f);
        }

        // 🟢 绿色：法师远程普攻回 2 血，大法球 (F) 回 10 血
        if (ballAttribute == AttributeType.Green)
        {
            playerStats.Heal(isBigBall ? 10f : 2f);
        }
    }
}