﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerStats : MonoBehaviour
{
    [Header("=== 基础属性 ===")]
    public float maxHealth = 100f;
    public float currentHealth;
    public float maxMana = 100f;
    public float currentMana; [Header("=== HUD UI 引用 ===")]
    public Image healthFill;
    public Image manaFill;
    public TextMeshProUGUI hudRedText;
    public TextMeshProUGUI hudBlueText;

    [Header("=== 死亡面板 ===")]
    public GameObject gameOverPanel;

    [Header("=== 背包 UI 引用 ===")]
    public Sprite redPotionSprite;
    public Sprite bluePotionSprite;
    public List<InventorySlot> inventorySlots; [Header("=== 药水恢复量 ===")]
    public float potionHealAmount = 30f;
    public float potionManaAmount = 30f; [Header("=== 消耗品数量 ===")]
    public int redPotionCount = 0;
    public int bluePotionCount = 0;

    [Header("=== 特效与设置 ===")]
    public float lerpSpeed = 10f;
    public ParticleSystem healParticlePrefab;
    public ParticleSystem manaParticlePrefab;
    public float iFrameDuration = 1.0f;
    private bool isInvincible = false;
    private SpriteRenderer sr; [Header("=== 音频 ===")]
    public AudioSource sfxSource;
    public AudioClip hurtSound;

    void Start()
    {
        currentHealth = maxHealth;
        currentMana = maxMana;
        sr = GetComponent<SpriteRenderer>();
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        UpdateUI();
    }

    void Update()
    {
        // 血条和蓝条的平滑过渡
        if (healthFill) healthFill.fillAmount = Mathf.Lerp(healthFill.fillAmount, currentHealth / maxHealth, Time.deltaTime * lerpSpeed);
        if (manaFill) manaFill.fillAmount = Mathf.Lerp(manaFill.fillAmount, currentMana / maxMana, Time.deltaTime * lerpSpeed);

        // --- 药水按键逻辑 ---
        if (Input.GetKeyDown(KeyCode.Q)) UseRedPotion();
        if (Input.GetKeyDown(KeyCode.E)) UseBluePotion();
    }

    // --- 药水使用逻辑 ---
    public void UseRedPotion()
    {
        if (redPotionCount > 0 && currentHealth < maxHealth)
        {
            redPotionCount--;
            Heal(potionHealAmount);
            UpdateUI();
            Debug.Log("使用了红药水");
        }
    }

    public void UseBluePotion()
    {
        if (bluePotionCount > 0 && currentMana < maxMana)
        {
            bluePotionCount--;
            RestoreMana(potionManaAmount);
            UpdateUI();
            Debug.Log("使用了蓝药水");
        }
    }

    // --- 受伤与死亡 ---
    public void TakeDamage(float amount)
    {
        if (isInvincible) return;
        if (sfxSource && hurtSound) sfxSource.PlayOneShot(hurtSound);

        currentHealth -= amount;
        currentHealth = Mathf.Max(currentHealth, 0);
        UpdateUI();

        if (currentHealth > 0) StartCoroutine(BecomeInvincible());
        else Die();
    }

    void Die()
    {
        if (gameOverPanel != null) gameOverPanel.SetActive(true);
        Time.timeScale = 0f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void OnClick_Restart()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void OnClick_QuitToMain()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(0);
    }

    // --- 恢复逻辑 ---
    public void Heal(float amount)
    {
        currentHealth = Mathf.Min(currentHealth + amount, maxHealth);
        if (healParticlePrefab) PlayEffect(healParticlePrefab);
    }

    public void RestoreMana(float amount)
    {
        currentMana = Mathf.Min(currentMana + amount, maxMana);
        if (manaParticlePrefab) PlayEffect(manaParticlePrefab);
    }

    public bool ConsumeMana(float amount)
    {
        if (currentMana >= amount) { currentMana -= amount; UpdateUI(); return true; }
        return false;
    }

    // --- UI 与 工具 ---
    public void PickUpPotion(bool isRed)
    {
        if (isRed) redPotionCount++;
        else bluePotionCount++;
        UpdateUI();
    }

    public void UpdateUI()
    {
        if (hudRedText) hudRedText.text = "x" + redPotionCount;
        if (hudBlueText) hudBlueText.text = "x" + bluePotionCount;
        RefreshBackpack();
    }

    void RefreshBackpack()
    {
        foreach (var slot in inventorySlots) if (slot != null) slot.ClearSlot();
        int idx = 0;
        if (redPotionCount > 0 && idx < inventorySlots.Count) inventorySlots[idx++].UpdateSlot(redPotionSprite, redPotionCount);
        if (bluePotionCount > 0 && idx < inventorySlots.Count) inventorySlots[idx++].UpdateSlot(bluePotionSprite, bluePotionCount);
    }

    private IEnumerator BecomeInvincible()
    {
        isInvincible = true;
        for (int i = 0; i < 5; i++)
        {
            if (sr) sr.color = new Color(1, 1, 1, 0.2f);
            yield return new WaitForSeconds(0.1f);
            if (sr) sr.color = new Color(1, 1, 1, 1f);
            yield return new WaitForSeconds(0.1f);
        }
        isInvincible = false;
    }

    void PlayEffect(ParticleSystem prefab)
    {
        ParticleSystem p = Instantiate(prefab, transform.position, Quaternion.identity);
        Destroy(p.gameObject, 1f);
    }

    public bool GetInvincible() => isInvincible;
}